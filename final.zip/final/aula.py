#!/usr/bin/env python
# -*- coding: utf-8 -*-

import main_win

def main():
	a = main_win.main_window()
        a.run()
	return 0

if __name__ == '__main__':
	main()

