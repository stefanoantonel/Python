#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  aula.py

import main_win

def main():
	
	a = main_win
	a= a.main_window()
	a.run()
	return 0

if __name__ == '__main__':
	main()

